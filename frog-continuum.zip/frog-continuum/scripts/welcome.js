Hooks.on("ready", async function() 
{
    //alert("welcome hook event fired.");
    if (game.user.isGM) 
    {
        class WelcomeScreen extends Application 
        {
            static get defaultOptions() {
                const options = super.defaultOptions;
                options.template = "modules/frog-continuum/templates/welcome-splash.html";
                options.resizable = false;
                options.width = 700;
                options.height = 475;
                options.popOut = true;
                //options.classes = ["drgh-encounters-1-welcome-screen"];
                options.title = "Welcome Screen";

                return options;
            }

            getData() {
                let data = {title: "Frogs in Space?!", moduleVersion: "1.0.4", isUnsupported: game.system.id === "dnd5e"}
                return data
            }
        }
        (new WelcomeScreen()).render(true);
    }
    
});
